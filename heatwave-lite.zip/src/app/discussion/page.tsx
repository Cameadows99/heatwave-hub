export default function DiscussionBoard() {
  return <h1 className="text-2xl font-bold">discussions</h1>
}